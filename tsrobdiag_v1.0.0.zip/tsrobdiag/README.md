# tsrobdiag

Normality and parameter-stability tests for serially correlated time series (Stata 14+).

* `tsnormal`: Bai-Ng (2005) skewness, kurtosis and joint tests with HAC variances; Lobato-Velasco (2004) test; Anderson-Darling and Jarque-Bera tests with an AR-sieve bootstrap under the Gaussian null. Works on series or on the residuals of the last estimation.
* `hansenstab`: Nyblom (1989) and Hansen (1992) parameter-stability tests, individual and joint, with iid or HAC variances, exact asymptotic p-values for any number of parameters, and wild or dependent wild bootstrap p-values.

## Installation

```
net install tsrobdiag, from("folder or URL containing tsrobdiag.pkg")
```

## Example

```
bcuse intdef, clear
tsset year
regress i3 inf def
hansenstab, kernel(qs)
tsnormal, boot(999) seed(20261025)
```

Author: Yusuf Toyin Yusuf, Kwara State University (yusuf.yusuf@kwasu.edu.ng). License: MIT.
